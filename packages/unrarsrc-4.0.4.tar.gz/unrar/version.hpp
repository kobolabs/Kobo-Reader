#define RARVER_MAJOR     4
#define RARVER_MINOR     0
#define RARVER_BETA      4
#define RARVER_DAY       4
#define RARVER_MONTH     1
#define RARVER_YEAR   2011
