MSVC project files for libmng.dll
---------------------------------

Contribution by Chad Austin
(This README by Gerard Juyn)

These project files were kindly donated by Chad. Please note that it
requires jpeglib, zlib and lcms to be in a directory which is at the
same level as the libmng directory.

I'm not sure how things work, since I don't have access to MSVC, so
it could be this needs a little tweaking, considering the location
where I put contributions.

As to the DLL itself. If you want to distribute libmng.dll with your
Application and store it in the standard Windows system-directory, you
*must* use the libmng.dll provided in this distribution. *Not* a dll
you have compiled yourself, unless you place this dll in the same
directory as your own Application!!!

Thanks,

Gerard
