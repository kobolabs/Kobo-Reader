#define   TAGLIB_WITH_ASF 1
#define   TAGLIB_WITH_MP4 1
