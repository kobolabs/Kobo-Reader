<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP">
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>ファイル(&amp;F)</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>終了(&amp;X)</translation>
    </message>
    <message>
        <source>First</source>
        <translation>第一行</translation>
    </message>
    <message>
        <source>Internationalization Example</source>
        <translation>国際化(i18n)の例</translation>
    </message>
    <message>
        <source>Isometric</source>
        <translation>等角投影法</translation>
    </message>
    <message>
        <source>Language: %1</source>
        <translation>言語: %1</translation>
    </message>
    <message>
        <source>English</source>
        <translation>日本語</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>斜め投影法</translation>
    </message>
    <message>
        <source>Perspective</source>
        <translation>遠近法</translation>
    </message>
    <message>
        <source>Second</source>
        <translation>第二行</translation>
    </message>
    <message>
        <source>Third</source>
        <translation>第三行</translation>
    </message>
    <message>
        <source>View</source>
        <translation>表示方式</translation>
    </message>
    <message>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
