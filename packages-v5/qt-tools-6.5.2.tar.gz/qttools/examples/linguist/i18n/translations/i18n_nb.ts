<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nb_NO">
<context>
    <name>MainWindow</name>
    <message>
        <source>View</source>
        <translation>Vis</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Fil</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Avslutt</translation>
    </message>
    <message>
        <source>First</source>
        <translation>Første</translation>
    </message>
    <message>
        <source>Third</source>
        <translation>Tredje</translation>
    </message>
    <message>
        <source>Language: %1</source>
        <translation>Språk: %1</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Norsk</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>Skjevt</translation>
    </message>
    <message>
        <source>Second</source>
        <translation>Andre</translation>
    </message>
    <message>
        <source>Isometric</source>
        <translation>Isometrisk</translation>
    </message>
    <message>
        <source>Perspective</source>
        <translation>Perspektiv</translation>
    </message>
    <message>
        <source>Internationalization Example</source>
        <translation>Internasjonaliseringseksempel</translation>
    </message>
    <message>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
