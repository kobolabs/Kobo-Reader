<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sv_SE">
<context>
    <name>MainWindow</name>
    <message>
        <source>View</source>
        <translation>Visa</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Arkiv</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Avsluta</translation>
    </message>
    <message>
        <source>First</source>
        <translation>Första</translation>
    </message>
    <message>
        <source>Third</source>
        <translation>Tredje</translation>
    </message>
    <message>
        <source>Language: %1</source>
        <translation>Språk: %1</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Svenska</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>Skevt</translation>
    </message>
    <message>
        <source>Second</source>
        <translation>Andra</translation>
    </message>
    <message>
        <source>Isometric</source>
        <translation>Isometriskt</translation>
    </message>
    <message>
        <source>Perspective</source>
        <translation>Perspektivt</translation>
    </message>
    <message>
        <source>Internationalization Example</source>
        <translation>Internationaliseringsexempel</translation>
    </message>
    <message>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
