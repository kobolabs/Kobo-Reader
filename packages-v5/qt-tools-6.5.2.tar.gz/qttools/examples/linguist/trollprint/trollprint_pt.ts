<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>Troll Print 1.0</source>
        <translation>Troll Imprimir 1.0</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Sair</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>&amp;Sobre</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Sobre &amp;Qt</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Arquivo</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>A&amp;juda</translation>
    </message>
    <message>
        <source>About Troll Print 1.0</source>
        <translation>Sobre Troll Imprimir 1.0</translation>
    </message>
    <message>
        <source>Troll Print 1.0.

Copyright 1999 Software, Inc.</source>
        <translation>Troll Imprimir 1.0

Copyright 1999 Software, Inc.</translation>
    </message>
    <message>
        <source>Ctrl+Q</source>
        <comment>Quit</comment>
        <translation>Ctrl+Q</translation>
    </message>
</context>
<context>
    <name>PrintPanel</name>
    <message>
        <source>2-sided</source>
        <translation>2-lados</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Ativado</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Desativado</translation>
    </message>
    <message>
        <source>Colors</source>
        <translation>Cores</translation>
    </message>
</context>
</TS>
