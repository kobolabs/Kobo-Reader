// Copyright (C) 2022 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause

#ifndef HEARTRATEGLOBAL_H
#define HEARTRATEGLOBAL_H

extern bool simulator;

#endif // HEARTRATEGLOBAL_H
