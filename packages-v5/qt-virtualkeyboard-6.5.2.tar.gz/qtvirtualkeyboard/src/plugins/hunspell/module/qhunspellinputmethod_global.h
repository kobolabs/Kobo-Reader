// Copyright (C) 2018 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR GPL-3.0-only

#ifndef QHUNSPELLINPUTMETHOD_GLOBAL_H
#define QHUNSPELLINPUTMETHOD_GLOBAL_H

#include <QtCore/qglobal.h>
#include <QtHunspellInputMethod/qthunspellinputmethodexports.h>

#endif
