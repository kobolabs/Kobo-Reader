// Copyright (C) 2021 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR GPL-3.0-only

#include "xt9kdbelement.h"

QT_BEGIN_NAMESPACE
namespace QtVirtualKeyboard {

Xt9KdbElement::~Xt9KdbElement()
{

}

} // namespace QtVirtualKeyboard
QT_END_NAMESPACE
