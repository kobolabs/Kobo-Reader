// Copyright (C) 2022 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR GPL-3.0-only

#ifndef QVIRTUALKEYBOARD_NAMESPACE_H
#define QVIRTUALKEYBOARD_NAMESPACE_H

#if 0
#  pragma qt_sync_skip_header_check
#endif
// TODO: Remove in Qt 7
#include <QtVirtualKeyboard/qvirtualkeyboardnamespace.h>

#endif // QVIRTUALKEYBOARD_NAMESPACE_H
