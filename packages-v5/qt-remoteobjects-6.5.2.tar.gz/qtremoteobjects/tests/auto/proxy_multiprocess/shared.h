const MyPOD initialValue(MyPOD::Position::position1, 3.14, QStringLiteral("SubClass"));
const MyPOD updatedValue(MyPOD::Position::position2 | MyPOD::Position::position3, 123.456, QStringLiteral("Updated"));
const VariantPOD podValue(10, 11);
const int initialI = 100;
const int updatedI = 200;

