// Copyright (C) 2017 Ford Motor Company
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR GPL-3.0-only WITH Qt-GPL-exception-1.0

#include <QRemoteObjectNode>

#include "rep_pod_replica.h"

int main(int argc, char **argv)
{
  QRemoteObjectNode node;

  MyClassReplica replica;

  return 0;
}
