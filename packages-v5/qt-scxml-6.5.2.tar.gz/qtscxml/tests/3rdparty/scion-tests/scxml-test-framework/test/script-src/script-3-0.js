function foo(){
    x = 100;
}
