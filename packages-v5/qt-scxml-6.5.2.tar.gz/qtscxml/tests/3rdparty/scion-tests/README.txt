Test Suite taken from https://github.com/jbeard4/scxml-test-framework,
the test framework of https://github.com/jbeard4/SCION .
It is licensed with the Apache 2.0 license, see LICENSE.txt  
