# Qt Quick 3D Physics Module

The purpose of this module is to demonstrate the usage of PhysX Physics engine with Qt Quick 3D.

