// Copyright (C) 2019 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR GPL-3.0-only WITH Qt-GPL-exception-1.0

#include <QtJsonRpc/qjsonrpcprotocol.h>

int main(int argc, char **argv)
{
    Q_UNUSED(argc);
    Q_UNUSED(argv);

    QJsonRpcProtocol protocol;
    Q_UNUSED(protocol);
    return 0;
}
