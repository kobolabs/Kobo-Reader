// Copyright (C) 2015 basysKom GmbH, opensource@basyskom.com
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only

#include "qopcuaplugin.h"

QT_BEGIN_NAMESPACE

QOpcUaPlugin::QOpcUaPlugin(QObject *parent)
    : QObject(parent)
{
}

QOpcUaPlugin::~QOpcUaPlugin()
{
}

QT_END_NAMESPACE
