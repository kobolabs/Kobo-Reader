// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause

#ifndef PERFORMANCEMONITORDECLARATIVE_H
#define PERFORMANCEMONITORDECLARATIVE_H

namespace PerformanceMonitor {
void qmlRegisterTypes();
}

#endif // PERFORMANCEMONITORDECLARATIVE_H
