// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR GPL-3.0-only WITH Qt-GPL-exception-1.0

#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>

const int format = GL_VIV_YV12;

int main(int argc, char** argv)
{
    return 0;
}
