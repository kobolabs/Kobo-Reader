// Copyright (C) 2017 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause

//If wayland-scanner is available, the following file should exist
#include "wayland-scanner-test-client-protocol.h"

int main()
{
    return 0;
}
